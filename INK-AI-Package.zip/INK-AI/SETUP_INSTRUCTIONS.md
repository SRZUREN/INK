# INK AI - Setup Instructions

## 📋 Requirements

- Python 3.11 or higher
- Internet connection for first-time setup
- Google Gemini API key (free)

## 🚀 Quick Start Guide

### Step 1: Extract the Files

Unzip the `INK-AI-Package.zip` file to your desired location. The folder structure should look like this:

```
INK-AI/
├── ink.py                 # Main application
├── templates/
│   └── index.html        # Web interface
├── requirements.txt      # Python dependencies
├── SETUP_INSTRUCTIONS.md # This file
└── README.md            # Documentation
```

### Step 2: Get Your Gemini API Key

1. Visit: https://makersuite.google.com/app/apikey
2. Sign in with your Google account
3. Click "Create API Key"
4. Copy the API key (you'll need it in the next step)

### Step 3: Set Up Environment Variable

#### On Windows:

**Option A: Temporary (for current session)**
```cmd
set GEMINI_API_KEY=your-api-key-here
```

**Option B: Permanent**
1. Right-click on "This PC" or "My Computer"
2. Click "Properties"
3. Click "Advanced system settings"
4. Click "Environment Variables"
5. Under "User variables", click "New"
6. Variable name: `GEMINI_API_KEY`
7. Variable value: Your API key
8. Click OK

#### On Mac/Linux:

**Option A: Temporary (for current session)**
```bash
export GEMINI_API_KEY="your-api-key-here"
```

**Option B: Permanent**

Add to your `~/.bashrc` or `~/.zshrc`:
```bash
echo 'export GEMINI_API_KEY="your-api-key-here"' >> ~/.bashrc
source ~/.bashrc
```

### Step 4: Run INK AI

Open a terminal/command prompt in the INK-AI folder and run:

```bash
python ink.py
```

Or on some systems:
```bash
python3 ink.py
```

That's it! INK will:
- ✅ Auto-install all required dependencies
- ✅ Create necessary cache folders
- ✅ Start the web server
- ✅ Open your browser automatically to http://localhost:5000

## 💬 Using INK AI

### Basic Chat
Just type your message and press Enter or click Send.

### Commands

| Command | Example | Description |
|---------|---------|-------------|
| `/code [description]` | `/code python function to reverse a string` | Generate production-ready code |
| `/svg [description]` | `/svg blue circle` | Create SVG images |
| `/train [instruction]` | `/train be more concise` | Customize AI behavior |
| `/clear` | `/clear` | Clear conversation history |

### Examples

**Generate Code:**
```
/code create a REST API with Flask that has endpoints for users
```

**Create SVG:**
```
/svg gold star
```

**Ask Questions:**
```
What is machine learning?
```

**Train the AI:**
```
/train respond like a professional software engineer
```

## 🔧 Troubleshooting

### Port Already in Use

If you get a "Port 5000 is in use" error:

**Windows:**
```cmd
taskkill /F /IM python.exe
```

**Mac/Linux:**
```bash
pkill -f "python ink.py"
```

Then run `python ink.py` again.

### Missing Dependencies

If dependencies don't auto-install, manually install them:

```bash
pip install -r requirements.txt
```

Or:

```bash
pip install flask google-generativeai svgwrite
```

### API Key Not Found

Make sure your `GEMINI_API_KEY` environment variable is set:

**Check on Windows:**
```cmd
echo %GEMINI_API_KEY%
```

**Check on Mac/Linux:**
```bash
echo $GEMINI_API_KEY
```

If it shows nothing, go back to Step 3 and set it up.

### Browser Doesn't Open Automatically

Manually open your browser and go to:
```
http://localhost:5000
```

## 📁 Files and Folders

After first run, you'll see these folders created:

```
cache/
├── conversations/     # Your chat history (JSON)
├── images/           # Generated SVG files
└── datasets/         # Training data storage
```

All your conversations are saved in `cache/conversations/memory.json`.

## 🌐 Network Access

To access INK from other devices on your network:

1. Find your computer's IP address:
   - Windows: Run `ipconfig` in cmd
   - Mac/Linux: Run `ifconfig` or `ip addr`

2. On other devices, visit:
   ```
   http://YOUR-IP-ADDRESS:5000
   ```

## 🔒 Security Notes

- Your API key is stored in environment variables (secure)
- All conversations are stored locally on your computer
- No data is sent anywhere except to Google Gemini for AI responses
- Never share your `GEMINI_API_KEY` with others

## 💾 Backing Up Your Data

To backup your conversations:
1. Copy the entire `cache` folder
2. Save it somewhere safe
3. To restore, just copy it back

## 📞 Need Help?

- Check the README.md for more details
- Make sure Python 3.11+ is installed: `python --version`
- Verify your API key is valid at https://makersuite.google.com/app/apikey

## 🎯 What's Next?

- Try all the commands
- Generate complex code with `/code`
- Create SVG graphics with `/svg`
- Train the AI to respond differently with `/train`
- Explore the Discord-style interface

Enjoy using INK AI! 🚀
