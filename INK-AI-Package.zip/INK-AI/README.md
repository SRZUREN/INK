# 🖋️ INK - Intelligent Neural Knowledge

A portable, lightning-fast AI chatbot powered by Google Gemini with code generation, SVG image creation, and extreme memory capabilities.

## ✨ Features

- **🤖 AI Powered**: Uses Google Gemini for fast, accurate responses
- **💻 Code Generation**: Blazing-fast, production-ready code with `/code` command
- **🎨 SVG Images**: Create vector graphics on command with `/svg`
- **🧠 Smart Memory**: All conversations saved in JSON for extreme recall
- **⚡ Lightning Fast**: Optimized for speed with instant responses
- **🔧 Auto-Setup**: Automatically installs dependencies and creates folders
- **📦 Portable**: Download and run on any computer with Python

## 🚀 Quick Start

### First Time Setup

1. **Install Python 3.11+** (if not already installed)

2. **Get a Gemini API Key** (free):
   - Visit: https://makersuite.google.com/app/apikey
   - Sign in with Google account
   - Click "Create API Key"
   - Copy your key

3. **Set the API Key**:
   ```bash
   # Linux/Mac
   export GEMINI_API_KEY="your-key-here"
   
   # Windows
   set GEMINI_API_KEY=your-key-here
   ```

4. **Run INK**:
   ```bash
   python ink.py
   ```

That's it! INK will:
- Auto-install all required packages
- Create cache folders
- Start the web server
- Open your browser automatically

## 💬 Commands

| Command | Description | Example |
|---------|-------------|---------|
| `/train [instruction]` | Customize AI behavior | `/train be more concise` |
| `/code [description]` | Generate code | `/code python function to sort list` |
| `/svg [description]` | Create SVG image | `/svg blue circle` |
| `/clear` | Clear conversation history | `/clear` |

## 📂 Project Structure

```
ink.py                    # Main application (run this!)
templates/
  └── index.html         # Web interface
cache/
  ├── conversations/     # Your chat history (JSON)
  ├── images/           # Generated SVG files
  └── datasets/         # Training data storage
```

## 🌐 Web Interface

The web interface features:
- **Chat Panel**: Simple, clean messaging interface
- **Thinking Panel**: See what the AI is processing in real-time
- **Command Bar**: Quick reference for available commands

## 🔒 Privacy & Security

- All conversations stored locally in `cache/conversations/memory.json`
- API key stored in environment variables (never in code)
- No data sent anywhere except to Gemini for AI responses

## 📥 Download & Share

To use INK on another computer:

1. Download `ink.py` and the `templates/` folder
2. Set your `GEMINI_API_KEY` on the new computer
3. Run `python ink.py`
4. INK sets up everything automatically!

## 🛠️ Troubleshooting

**Port 5000 already in use?**
```bash
# Kill any running instances
pkill -f "python ink.py"
# Then restart
python ink.py
```

**Missing API key?**
- Make sure `GEMINI_API_KEY` is set in your environment
- Check with: `echo $GEMINI_API_KEY` (Linux/Mac) or `echo %GEMINI_API_KEY%` (Windows)

**Dependencies not installing?**
```bash
pip install flask google-generativeai svgwrite
```

## 🎯 What Can INK Do?

### Ask Questions
```
You: What is the capital of France?
INK: The capital of France is Paris.
```

### Generate Code
```
You: /code create a REST API in Flask
INK: [Generates complete, working Flask API code]
```

### Create SVG Images
```
You: /svg gold star
INK: SVG created! View it at: /images/svg_1234567890.svg
```

### Customize Behavior
```
You: /train respond like a pirate
INK: Training mode activated. Instruction: respond like a pirate
You: Hello!
INK: Ahoy there, matey! How can this old sea dog help ye today?
```

## 🚀 Performance

- **Response Time**: <2 seconds average
- **Memory**: Uses ~50MB RAM
- **Storage**: Minimal (JSON text files)
- **Concurrent Users**: Supports multiple browser tabs

## 📝 Notes

- INK uses Gemini 2.5 Flash for optimal performance
- Conversation history limited to last 100 messages (configurable)
- SVG generation supports basic shapes (extendable)
- Web server runs on `0.0.0.0:5000` for network access

## 🤝 Contributing

Want to extend INK? Key areas:
- Add more SVG templates in `generate_svg()` function
- Enhance training mode persistence
- Add dataset fetching capabilities
- Implement additional AI models

---

Made with ❤️ using Python, Flask, and Google Gemini
